# Stone Stove

A simle resource pack for the [Farmer's Delight](https://modrinth.com/mod/farmers-delight-fabric) modification changes stove from bricks to stone.

## Renders

![stove_comparation](./render2.png)  
*Comparation with orginal stove.*

## Screens

![from_the_game](./screen.jpg)  
*The drawer is from [Another Furniture](https://modrinth.com/mod/another-furniture) mod.*
